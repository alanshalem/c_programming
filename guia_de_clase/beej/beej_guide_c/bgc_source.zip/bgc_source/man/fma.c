#include <stdio.h>
#include <math.h>

int main(void)
{
    printf("%f\n", fma(1.0, 2.0, 3.0));  // 5.000000
}

