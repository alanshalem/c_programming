#include <stdio.h>

#define SQR(x) ((x) * (x))    // Good!

int main(void)
{
    printf("%d\n", SQR(12));  // 144
}
