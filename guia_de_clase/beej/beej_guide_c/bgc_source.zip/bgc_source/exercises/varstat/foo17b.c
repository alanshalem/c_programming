#include <stdio.h>

int main(void)
{
    int i = 3490;

    printf("%s\n", i > 17? "foo": "bar");
}
