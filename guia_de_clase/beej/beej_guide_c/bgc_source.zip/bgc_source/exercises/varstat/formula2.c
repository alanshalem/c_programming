#include <stdio.h>

int main(void)
{
    int x = 71;
    float result = (x + 10 * x - 5) / 2.0;

    printf("%f\n", result);
}
