#include <stdio.h>

int main(void)
{
    int x = 71;
    int result = (x + 10 * x - 5) / 2;

    printf("%d\n", result);
}
