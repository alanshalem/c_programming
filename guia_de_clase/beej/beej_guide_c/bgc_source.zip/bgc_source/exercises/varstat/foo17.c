#include <stdio.h>

int main(void)
{
    int i = 3490;

    if (i > 17)
        printf("foo\n");
    else
        printf("bar\n");
}
