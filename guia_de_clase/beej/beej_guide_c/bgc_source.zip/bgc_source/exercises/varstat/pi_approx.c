#include <stdio.h>

int main(void)
{
    float pi = 208341.0 / 66317;

    printf("%f\n", pi);
}
