#include <stdio.h>

int main(void)
{
    printf("Beej Jorgensen of the Hill People\n");
    printf("Durian\n");
}
