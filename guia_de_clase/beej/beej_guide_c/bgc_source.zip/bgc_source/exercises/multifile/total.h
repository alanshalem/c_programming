#ifndef TOTAL_H
#define TOTAL_H

extern int count;
extern int add(int x);
extern int total(void);

#endif
