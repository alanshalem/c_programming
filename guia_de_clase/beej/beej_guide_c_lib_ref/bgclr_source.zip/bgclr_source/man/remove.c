#include <stdio.h>

int main(void)
{
    char *filename = "evidence.txt";

    remove(filename);
}
